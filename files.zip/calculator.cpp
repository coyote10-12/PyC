#include <iostream>
#include <string>
#include <cmath>
#include <sstream>
#include <stdexcept>
#include <cctype>
#include <vector>

// For HTTP server (using a simple approach)
#include <http_server.h>  // You'll need a C++ HTTP library

class ScientificCalculator {
private:
    double pi = 3.141592653589793;
    std::string angleMode = "deg";  // "deg" or "rad"

public:
    ScientificCalculator() {}

    void setAngleMode(const std::string& mode) {
        angleMode = mode;
    }

    double degreesToRadians(double degrees) {
        return degrees * (pi / 180.0);
    }

    double radiansToDegrees(double radians) {
        return radians * (180.0 / pi);
    }

    // Trigonometric Functions
    double sine(double x) {
        if (angleMode == "deg") {
            x = degreesToRadians(x);
        }
        return std::sin(x);
    }

    double cosine(double x) {
        if (angleMode == "deg") {
            x = degreesToRadians(x);
        }
        return std::cos(x);
    }

    double tangent(double x) {
        if (angleMode == "deg") {
            x = degreesToRadians(x);
        }
        return std::tan(x);
    }

    // Inverse Trigonometric Functions
    double arcSine(double x) {
        if (x < -1.0 || x > 1.0) {
            throw std::invalid_argument("asin domain error: input must be between -1 and 1");
        }
        double result = std::asin(x);
        if (angleMode == "deg") {
            result = radiansToDegrees(result);
        }
        return result;
    }

    double arcCosine(double x) {
        if (x < -1.0 || x > 1.0) {
            throw std::invalid_argument("acos domain error: input must be between -1 and 1");
        }
        double result = std::acos(x);
        if (angleMode == "deg") {
            result = radiansToDegrees(result);
        }
        return result;
    }

    double arcTangent(double x) {
        double result = std::atan(x);
        if (angleMode == "deg") {
            result = radiansToDegrees(result);
        }
        return result;
    }

    // Other Functions
    double squareRoot(double x) {
        if (x < 0) {
            throw std::invalid_argument("sqrt: negative number");
        }
        return std::sqrt(x);
    }

    double logarithm(double x) {
        if (x <= 0) {
            throw std::invalid_argument("log: input must be positive");
        }
        return std::log10(x);
    }

    double exponential(double x) {
        return std::exp(x);
    }

    double power(double base, double exponent) {
        return std::pow(base, exponent);
    }

    // Main calculation parser
    double calculate(const std::string& expression) {
        // Simple expression parser
        std::string expr = expression;
        
        // Replace constants
        replaceAll(expr, "pi", std::to_string(pi));
        
        // For a production calculator, you'd implement a proper expression parser
        // This is a simplified version
        try {
            return evaluateExpression(expr);
        } catch (const std::exception& e) {
            throw std::runtime_error(std::string("Calculation error: ") + e.what());
        }
    }

private:
    void replaceAll(std::string& str, const std::string& from, const std::string& to) {
        size_t start_pos = 0;
        while ((start_pos = str.find(from, start_pos)) != std::string::npos) {
            str.replace(start_pos, from.length(), to);
            start_pos += to.length();
        }
    }

    // Simplified expression evaluator (handles basic operations)
    double evaluateExpression(const std::string& expr) {
        // This would need to be expanded for full functionality
        // For now, we'll use a basic recursive descent parser
        
        // In production, use a proper math expression parser library
        // like mParser, muparser, or write a complete recursive descent parser
        
        throw std::runtime_error("Expression parser not fully implemented in this demo");
    }
};

// Example usage
int main() {
    ScientificCalculator calc;
    calc.setAngleMode("deg");
    
    std::cout << "Scientific Calculator (C++)" << std::endl;
    std::cout << "sin(30) = " << calc.sine(30) << std::endl;
    std::cout << "cos(60) = " << calc.cosine(60) << std::endl;
    std::cout << "tan(45) = " << calc.tangent(45) << std::endl;
    std::cout << "sqrt(16) = " << calc.squareRoot(16) << std::endl;
    std::cout << "2^3 = " << calc.power(2, 3) << std::endl;
    
    return 0;
}