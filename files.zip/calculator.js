class ScientificCalculator {
    constructor() {
        this.expressionDisplay = document.getElementById('expression');
        this.resultDisplay = document.getElementById('result');
        this.currentExpression = '';
        this.pi = Math.PI;
        this.angleMode = 'deg';
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Angle mode change
        document.querySelectorAll('input[name="angle-mode"]').forEach(input => {
            input.addEventListener('change', (e) => {
                this.angleMode = e.target.value;
            });
        });

        // Keyboard support
        document.addEventListener('keydown', (e) => this.handleKeyboard(e));
    }

    handleKeyboard(e) {
        if (e.key >= '0' && e.key <= '9') {
            this.appendNumber(e.key);
        } else if (['+', '-', '*', '/', '.', '^', '%'].includes(e.key)) {
            e.preventDefault();
            this.appendOperator(e.key === '^' ? '^' : e.key);
        } else if (e.key === 'Enter') {
            e.preventDefault();
            this.calculate();
        } else if (e.key === 'Backspace') {
            e.preventDefault();
            this.deleteLastChar();
        } else if (e.key === 'Escape') {
            this.clearDisplay();
        } else if (e.key === '(') {
            this.appendChar('(');
        } else if (e.key === ')') {
            this.appendChar(')');
        }
    }

    appendNumber(num) {
        this.currentExpression += num;
        this.updateDisplay();
    }

    appendChar(char) {
        this.currentExpression += char;
        this.updateDisplay();
    }

    appendOperator(op) {
        // Prevent multiple operators in a row
        if (this.currentExpression === '') return;
        
        const lastChar = this.currentExpression.slice(-1);
        if (['+', '-', '*', '/', '^', '%'].includes(lastChar)) {
            return;
        }
        
        this.currentExpression += op;
        this.updateDisplay();
    }

    appendFunction(func) {
        if (func === 'pi') {
            this.currentExpression += this.pi.toString();
        } else {
            this.currentExpression += func + '(';
        }
        this.updateDisplay();
    }

    deleteLastChar() {
        this.currentExpression = this.currentExpression.slice(0, -1);
        this.updateDisplay();
    }

    clearDisplay() {
        this.currentExpression = '';
        this.updateDisplay();
    }

    toggleSign() {
        if (this.currentExpression === '') return;
        
        // Try to find the last number and toggle its sign
        let lastNumMatch = this.currentExpression.match(/[\d.]+$/);
        if (lastNumMatch) {
            const lastNum = lastNumMatch[0];
            const beforeNum = this.currentExpression.slice(0, -lastNum.length);
            
            if (lastNum.startsWith('-')) {
                this.currentExpression = beforeNum + lastNum.slice(1);
            } else {
                this.currentExpression = beforeNum + '-' + lastNum;
            }
        }
        this.updateDisplay();
    }

    updateDisplay() {
        this.expressionDisplay.value = this.currentExpression;
    }

    degreesToRadians(degrees) {
        return degrees * (Math.PI / 180);
    }

    radiansToDegrees(radians) {
        return radians * (180 / Math.PI);
    }

    // Trigonometric functions with angle mode support
    sin(x) {
        if (this.angleMode === 'deg') {
            x = this.degreesToRadians(x);
        }
        return Math.sin(x);
    }

    cos(x) {
        if (this.angleMode === 'deg') {
            x = this.degreesToRadians(x);
        }
        return Math.cos(x);
    }

    tan(x) {
        if (this.angleMode === 'deg') {
            x = this.degreesToRadians(x);
        }
        return Math.tan(x);
    }

    asin(x) {
        if (Math.abs(x) > 1) {
            throw new Error('asin: input must be between -1 and 1');
        }
        let result = Math.asin(x);
        if (this.angleMode === 'deg') {
            result = this.radiansToDegrees(result);
        }
        return result;
    }

    acos(x) {
        if (Math.abs(x) > 1) {
            throw new Error('acos: input must be between -1 and 1');
        }
        let result = Math.acos(x);
        if (this.angleMode === 'deg') {
            result = this.radiansToDegrees(result);
        }
        return result;
    }

    atan(x) {
        let result = Math.atan(x);
        if (this.angleMode === 'deg') {
            result = this.radiansToDegrees(result);
        }
        return result;
    }

    sqrt(x) {
        if (x < 0) {
            throw new Error('sqrt: negative number');
        }
        return Math.sqrt(x);
    }

    log(x) {
        if (x <= 0) {
            throw new Error('log: input must be positive');
        }
        return Math.log(x);
    }

    log10(x) {
        if (x <= 0) {
            throw new Error('log10: input must be positive');
        }
        return Math.log10(x);
    }

    exp(x) {
        return Math.exp(x);
    }

    abs(x) {
        return Math.abs(x);
    }

    validateAndPrepareExpression(expr) {
        // Check for balanced parentheses
        let parenCount = 0;
        for (let char of expr) {
            if (char === '(') parenCount++;
            if (char === ')') parenCount--;
            if (parenCount < 0) {
                throw new Error('Mismatched parentheses');
            }
        }
        if (parenCount !== 0) {
            throw new Error('Mismatched parentheses');
        }

        // Replace function names with Math object calls
        let prepared = expr
            .replace(/sin\(/g, 'calc.sin(')
            .replace(/cos\(/g, 'calc.cos(')
            .replace(/tan\(/g, 'calc.tan(')
            .replace(/asin\(/g, 'calc.asin(')
            .replace(/acos\(/g, 'calc.acos(')
            .replace(/atan\(/g, 'calc.atan(')
            .replace(/sqrt\(/g, 'calc.sqrt(')
            .replace(/log\(/g, 'calc.log(')
            .replace(/log10\(/g, 'calc.log10(')
            .replace(/exp\(/g, 'calc.exp(')
            .replace(/abs\(/g, 'calc.abs(')
            .replace(/\^/g, '**');

        return prepared;
    }

    calculate() {
        if (this.currentExpression.trim() === '') {
            return;
        }

        try {
            const prepared = this.validateAndPrepareExpression(this.currentExpression);
            
            // Use eval in a controlled manner with our calculator object
            const result = eval(prepared);
            
            // Check if result is a valid number
            if (typeof result !== 'number' || isNaN(result)) {
                throw new Error('Invalid calculation');
            }
            
            // Format the result
            let displayResult = result;
            if (!Number.isInteger(result)) {
                // Round to 10 decimal places to avoid floating point errors
                displayResult = Math.round(result * 10000000000) / 10000000000;
            }
            
            this.resultDisplay.value = displayResult;
            this.currentExpression = displayResult.toString();
            this.updateDisplay();
        } catch (error) {
            this.resultDisplay.value = 'Error: ' + error.message;
            console.error('Calculation error:', error);
        }
    }
}

// Initialize calculator when DOM is ready
let calc;
document.addEventListener('DOMContentLoaded', () => {
    calc = new ScientificCalculator();
    document.getElementById('result').value = '0';
});

// Make calculator functions accessible globally
function appendNumber(num) {
    calc.appendNumber(num);
}

function appendOperator(op) {
    calc.appendOperator(op);
}

function appendChar(char) {
    calc.appendChar(char);
}

function appendFunction(func) {
    calc.appendFunction(func);
}

function deleteLastChar() {
    calc.deleteLastChar();
}

function clearDisplay() {
    calc.clearDisplay();
}

function toggleSign() {
    calc.toggleSign();
}

function calculate() {
    calc.calculate();
}