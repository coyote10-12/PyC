#include <iostream>
#include <string>
#include <cmath>
#include <sstream>
#include <memory>

// Using cpp-httplib for simple HTTP server
// Install: vcpkg install cpp-httplib
#include <httplib.h>
#include <nlohmann/json.hpp>

using json = nlohmann::json;

class CalculatorEngine {
private:
    double pi = 3.141592653589793;
    std::string angleMode = "deg";

public:
    void setAngleMode(const std::string& mode) {
        angleMode = mode;
    }

    double degreesToRadians(double degrees) {
        return degrees * (pi / 180.0);
    }

    double radiansToDegrees(double radians) {
        return radians * (180.0 / pi);
    }

    double sine(double x) {
        if (angleMode == "deg") x = degreesToRadians(x);
        return std::sin(x);
    }

    double cosine(double x) {
        if (angleMode == "deg") x = degreesToRadians(x);
        return std::cos(x);
    }

    double tangent(double x) {
        if (angleMode == "deg") x = degreesToRadians(x);
        return std::tan(x);
    }

    double arcSine(double x) {
        if (x < -1.0 || x > 1.0) throw std::invalid_argument("asin domain error");
        double result = std::asin(x);
        if (angleMode == "deg") result = radiansToDegrees(result);
        return result;
    }

    double arcCosine(double x) {
        if (x < -1.0 || x > 1.0) throw std::invalid_argument("acos domain error");
        double result = std::acos(x);
        if (angleMode == "deg") result = radiansToDegrees(result);
        return result;
    }

    double arcTangent(double x) {
        double result = std::atan(x);
        if (angleMode == "deg") result = radiansToDegrees(result);
        return result;
    }

    double squareRoot(double x) {
        if (x < 0) throw std::invalid_argument("sqrt: negative number");
        return std::sqrt(x);
    }

    double logarithm(double x) {
        if (x <= 0) throw std::invalid_argument("log: input must be positive");
        return std::log10(x);
    }

    double exponential(double x) {
        return std::exp(x);
    }

    double power(double base, double exponent) {
        return std::pow(base, exponent);
    }

    double calculate(const std::string& expression) {
        std::string expr = expression;
        
        // Replace functions with Math object equivalents
        replaceAll(expr, "sin(", "sine(");
        replaceAll(expr, "cos(", "cosine(");
        replaceAll(expr, "tan(", "tangent(");
        replaceAll(expr, "asin(", "arcSine(");
        replaceAll(expr, "acos(", "arcCosine(");
        replaceAll(expr, "atan(", "arcTangent(");
        replaceAll(expr, "sqrt(", "squareRoot(");
        replaceAll(expr, "log(", "logarithm(");
        replaceAll(expr, "exp(", "exponential(");
        replaceAll(expr, "^", "**");
        replaceAll(expr, "pi", std::to_string(pi));
        
        // For production use, implement proper expression parser
        // This is a simplified demo
        throw std::invalid_argument("Expression parser needs proper implementation");
    }

private:
    void replaceAll(std::string& str, const std::string& from, const std::string& to) {
        size_t start_pos = 0;
        while ((start_pos = str.find(from, start_pos)) != std::string::npos) {
            str.replace(start_pos, from.length(), to);
            start_pos += to.length();
        }
    }
};

int main() {
    httplib::Server svr;
    CalculatorEngine engine;

    // Serve the HTML file
    svr.set_base_directory(".");

    // API endpoint for calculations
    svr.Post("/calculate", [&](const httplib::Request& req, httplib::Response& res) {
        try {
            auto body = json::parse(req.body);
            std::string expression = body["expression"];
            std::string angleMode = body["angleMode"];

            engine.setAngleMode(angleMode);
            double result = engine.calculate(expression);

            json response;
            response["result"] = result;
            response["error"] = nullptr;

            res.set_content(response.dump(), "application/json");
        } catch (const std::exception& e) {
            json response;
            response["result"] = nullptr;
            response["error"] = e.what();

            res.set_content(response.dump(), "application/json");
        }
    });

    std::cout << "Server running on http://localhost:8080" << std::endl;
    svr.listen("localhost", 8080);

    return 0;
}