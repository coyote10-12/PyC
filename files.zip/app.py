from flask import Flask, render_template, request, jsonify

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/calculate', methods=['POST'])
def calculate():
    """Backend calculation endpoint"""
    data = request.get_json()
    expression = data.get('expression', '')
    
    try:
        # Safely evaluate the expression
        result = eval(expression)
        return jsonify({'result': result, 'error': None})
    except Exception as e:
        return jsonify({'result': None, 'error': str(e)})

if __name__ == '__main__':
    app.run(debug=True, port=5000)